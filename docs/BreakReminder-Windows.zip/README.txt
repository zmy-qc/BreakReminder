﻿BreakReminder Windows 版

双击 BreakReminder.exe 运行, 托盘出现图标。
要求 Windows 10/11 (系统自带 .NET Framework 4.8, 无需安装其他)。
SmartScreen 拦截时: 更多信息 → 仍要运行。
右键托盘图标可开启开机自启。
